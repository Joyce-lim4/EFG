/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('loans', {
        id: 'id',
        reader_id: { type: 'uuid', notNull: true },
        exemplar_id: { type: 'uuid', notNull: true, references: 'exemplars(id)' },
        due_at: { type: 'TimpestampTz' },
        renewal_count: { type: 'interger', notNull: true, check: 'renewal_count >=0', default: 0 },
        status: { type: 'text', notNull: true, ckeck: "(status In('active', 'returned', 'lost', 'damaged'))" },
        createdAt: { type: 'timestampTz', notNull: true, dafault: pgm.func('now') },
    })
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = false
