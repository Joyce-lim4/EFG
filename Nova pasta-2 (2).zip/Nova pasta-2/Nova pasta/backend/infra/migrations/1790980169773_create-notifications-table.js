/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('notifications', {
        id: 'id',
        type: { type: 'text', notNull: true },
        entity_it: { type: 'uuid', notNull: true },
        reader_id: { type: 'uuid', notNull: true },
        channel: { type: 'text', notNull: true, check: "status In ('delivered', 'failed')", default: 'delivered' },
        attempts: { type: 'int', notNull: true, default: 1, check: 'attempts >= 1' },
        playload: { type: 'jsonb' },
        createdAt: { type: 'timestampTz', notNull: true, default: pgm.func('now') },
        deliveredAt: { type: 'timestampTz', notNull: true, default: pgm.func('now') }
    })
    pgm.addConstraint('notifications', 'unique(type,entity_id)')
};



/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = false
