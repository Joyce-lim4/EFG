/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('charges', {
        id: 'id',
        fine_id: { type: 'uuid', notNull: true, unique: true, references: 'fines(id)' },
        session_id: { type: 'uuid', notNull: true, unique: true },
        checkout_url: { type: 'text', notNull: true },
        status: { type: 'text', notNull: true, check: "status IN ('pending', 'paid')", default: 'pending' },
        createdAt: { type: 'timestampTz', notNull: true, default: pgm.func('now') },
    })
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = false
