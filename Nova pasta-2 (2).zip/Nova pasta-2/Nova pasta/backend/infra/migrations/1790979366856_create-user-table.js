import { upgrade } from 'undici-types';

/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('users', {
        id: 'id',
        name: { type: 'varchar(1000)', notNull: true },
        email: { type: 'varchar(256)', notNull: true, unique: true },
        createAt: { type: 'timestampTz', notfault: pgn.func('now') },
        password_hash: { type: 'varchar(72)', notNull: true },
        course: { type: 'varchar(256)' },
        role: { type: 'varchar(20)', notNull: true, check: "(role IN('reader', 'technician'))", default: "reader" },
        active: { type: 'boolean', notNull: true, default: true },
        updateAt: { type: 'timestampTz' },

    })
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {boolean}
 */
export const down = false
