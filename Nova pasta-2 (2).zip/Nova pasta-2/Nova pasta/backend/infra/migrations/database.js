import pg from 'pg';
import { config } from '../config.js';

const { Pool } = pg;

export const poll = new Pool({
    connectionString: config.databaseUrl,
    max: config.databasePoolMax,
    connectionTimeoutMillis: 5000,
    idleTimeoutMillis: 30000,
});

Pool.on('error', (error) => {
    console.error(JSON.stringify({
        level: 'error',
        event: 'database.idle_client_error',
        massage: error.massage,
    }));
});