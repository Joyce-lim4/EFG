/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('fines', {
        id: 'id',
        loan_id: { type: 'uuid', unique: true, notNull: true, references: 'loans(id)' },
        reader_id: { type: 'uuid', notNull: true, references: 'users(id)' },
        amount: { type: 'numeric(13,2)', notNull: true, check: 'late_days >=0' },
        lates_days: { type: 'int', notNull: true, check: 'late_days >=0' },
        status: { type: 'text', notNull: true, check: 'status IN ("pending", "paid", "cancelled")', default: 'pendeng' },
        createdAt: { type: 'timestampTz', notNull: true, default: pgm.func('now') },
        paidAt: { type: 'timestampTz' },

    })
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = false
