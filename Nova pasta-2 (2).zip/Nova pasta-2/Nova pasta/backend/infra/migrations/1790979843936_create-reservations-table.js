/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('reservations', {
        id: 'id',
        reader_id: { type: 'uuid', notNull: true, },
        exemplar_id: { type: 'uuid', notNull: true, references: 'exemplars(id)' },
        status: { type: 'text', notNull: true, check: "status IN ('active', 'ready', 'cancelled', 'expired', 'completed')" },
        createdAt: { type: 'timestampTz', notNull: true, default: pgm.func('now') },
        cancelledAt: { type: 'timestampTz' },

    })
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = false
