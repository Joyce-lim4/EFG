/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('exemplars', {
        id: 'id',
        books_id: { type: 'uuid', notNull: true, references: 'books(id)' },
        volume: { type: 'text' },
        print_run: { type: 'text' },
        print_year: { type: 'integer' },
        createdAt: { type: 'timestampTz', notNull: true, dafault: pgm.func('now') },
        updateAt: { type: 'timestampTz' },
    })
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = false
