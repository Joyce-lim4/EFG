/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('audit_events', {
        id: 'id',
        operation: { type: 'text', notNull: true },
        actor_id: { type: 'uuid' },
        actor_role: { type: 'text' },
        entity_type: { type: 'text', notNull: true },
        entity_id: { type: 'text', notNull: true },
        result: { type: 'text', notNull: true, check: 'result IN("success","denied", "error")' },
        correlation_id: { type: 'text' },
        details: { type: 'JSONB' },
        occured_at: { type: 'timestampTz', notNull: true, default: pgm.func('now') }
    })
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = false
