/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('books', {
        id: 'id', title: { type: 'text', notNull: true },
        author: { type: 'text', notNull: true },
        edition: { type: 'text' },
        createdAt: { type: 'timestampTz', notNull: true, default: pgm.func('now') },
        updateAt: { type: 'timestampTz' },
    })


};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = (pgm) => { };
