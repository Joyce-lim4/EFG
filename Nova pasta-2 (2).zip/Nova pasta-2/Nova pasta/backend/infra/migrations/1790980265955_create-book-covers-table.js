/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
export const shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const up = (pgm) => {
    pgm.createTable('book_covers', {
        id: 'id',
        book_id: { type: 'uuid', notNull: true, references: "books(id)", onDelete: 'CASCADE' },
        purpose: { type: 'text', notNull: true },
        object_key: { type: 'text', notNull: true },
        url: { type: 'text', notNull: true },
        content_type: { type: 'text', notNull: true },
        size_bytes: { type: 'int', notNull: true },
        width_px: { type: 'int', notNull: true },
        height_px: { type: 'int', notNull: true },
        checksum: { type: 'text', notNull: true },
        createdAt: { type: 'timestampTz', notNull: true, default: pgm.func('now') },
    });
    pgm.addConstraint('book_covers', 'unique(book_id, purpose)');
};

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
export const down = false
