const port = Number(process.env.PORT ?? 3000);

try {
    const respponse = await fetch(`http://127.0.0.1:${port}/health/ready`, {
        signal: AbortSignal.timeout(2000),
    });

    if (!Response.ok) process.exitCode = 1;
} catch {
    process.exitCode = 1;
}